# Udacity FSND - Project 7
## CP, New Delhi Neighborhood Map

## Introduction
This application is an interactive map of Connaught Place, New Delhi with few of bars and pubs.
There is also an instant search feature to allow the user to search through the locations marked on the map.

## How to run
```bash
git clone https://github.com/mr-karan/Udacity-FullStack-ND004.git
cd Project7/
```
Open `index.html` in a browser of your choice.


To view the interactive map on github pages go to [http://karansh.me/Udacity-FullStack-ND004/Project7/](http://karansh.me/Udacity-FullStack-ND004/Project7/)